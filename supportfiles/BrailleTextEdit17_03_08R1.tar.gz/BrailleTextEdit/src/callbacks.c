#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"




void on_window_destroy (GtkWindow *window)
{
	gtk_main_quit();
}

void
error_message (const gchar *message)
{
        GtkWidget               *dialog;
        
        /* log to terminal window */
        g_warning (message);
        
        /* create an error message dialog and display modally to the user */
        dialog = gtk_message_dialog_new (NULL, 
                                         GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                         GTK_MESSAGE_ERROR,
                                         GTK_BUTTONS_OK,
                                         message);
        
        gtk_window_set_title (GTK_WINDOW (dialog), "Error!");
        gtk_dialog_run (GTK_DIALOG (dialog));      
        gtk_widget_destroy (dialog);         
}


void 
reset_default_status (GtkWidget *window)
{
        gchar           *file;
        gchar           *status;
        
        if (filename == NULL)
        {
                file = g_strdup ("(Sin Titulo)");
        }
        else file = g_path_get_basename (filename);
        
        status = g_strdup_printf ("Archivo: %s", file);
	
        gtk_statusbar_pop (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
                           statusbar_context_id);
        gtk_statusbar_push (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
                            statusbar_context_id, status);
        g_free (status);
        g_free (file);
}

gchar *
get_open_filename (GtkWidget *window)
{
        GtkWidget               *chooser;
        gchar                   *filename_A=NULL;
                
        chooser = gtk_file_chooser_dialog_new ("Abrir Archivo...",
                                               GTK_WINDOW (window),
                                               GTK_FILE_CHOOSER_ACTION_OPEN,
                                               GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                               GTK_STOCK_OPEN, GTK_RESPONSE_OK,
                                               NULL);
                                               
        if (gtk_dialog_run (GTK_DIALOG (chooser)) == GTK_RESPONSE_OK)
        {
                filename_A = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (chooser));
        }
        
        gtk_widget_destroy (chooser);
        return filename_A;
}

gboolean 
check_for_save (GtkWidget *window)
{
	gboolean                ret = FALSE;
	GtkTextBuffer           *buffer;
	
	buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW(lookup_widget(window,"text_view")));
        
	if (gtk_text_buffer_get_modified (buffer) == TRUE)
	{
		/* we need to prompt for save */
                
		GtkWidget       *dialog;
                
		const gchar *msg  = "Desea guardar los cambios realizados?";
                
		dialog = gtk_message_dialog_new (NULL, 
				GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
    GTK_MESSAGE_QUESTION,
    GTK_BUTTONS_YES_NO,
    msg);
        
		gtk_window_set_title (GTK_WINDOW (dialog), "Guardar?");
		if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_NO)
		{
			ret = FALSE;
		}      
		else ret = TRUE;
                
		gtk_widget_destroy (dialog);      
	}     
        
	return ret;
}

void 
load_file (GtkWidget *window, gchar *filename_A)
{
        GError                  *err=NULL;
        gchar                   *status;
        gchar                   *text;
        gboolean                result;
        GtkTextBuffer           *buffer;
        
        /* add Loading message to status bar and  ensure GUI is current */
        status = g_strdup_printf ("Cargando %s...", filename_A);
        gtk_statusbar_push (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
                            statusbar_context_id, status);
        g_free (status);
        while (gtk_events_pending()) gtk_main_iteration();
        
        /* get the file contents */
        result = g_file_get_contents (filename_A, &text, NULL, &err);
        if (result == FALSE)
        {
                /* error loading file, show message to user */
                error_message (err->message);
                g_error_free (err);
                g_free (filename);
        }
        
        /* disable the text view while loading the buffer with the text */    
        gtk_widget_set_sensitive (lookup_widget(window,"text_view"), FALSE);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (lookup_widget(window,"text_view")));
        gtk_text_buffer_set_text (buffer, text, -1);
        gtk_text_buffer_set_modified (buffer, FALSE);
        gtk_widget_set_sensitive (lookup_widget(window,"text_view"), TRUE);
        g_free (text); 
        
        /* now we can set the current filename since loading was a success */
        if (filename != NULL) g_free (filename);
        filename = filename_A;
        
        /* clear loading status and restore default  */
        gtk_statusbar_pop (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
                           statusbar_context_id);
        reset_default_status (window);
}


void 
write_file (GtkWidget *window, gchar *filename_A)
{
	GError                  *err=NULL;
	gchar                   *status;
	gchar                   *text;
	gboolean                result;
	GtkTextBuffer           *buffer;
	GtkTextIter             start, end;

        
	/* add Saving message to status bar and ensure GUI is current */
	if (filename_A != NULL)
		status = g_strdup_printf ("Guardando %s...", filename_A);
	else
		status = g_strdup_printf ("Guardando %s...", filename);
            
	gtk_statusbar_push (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
			    statusbar_context_id, status);
	g_free (status);
	while (gtk_events_pending()) gtk_main_iteration();
        
	/* disable text view and get contents of buffer */ 
	gtk_widget_set_sensitive (lookup_widget(window,"text_view"), FALSE);
	buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW(lookup_widget(window,"text_view")));
	gtk_text_buffer_get_start_iter (buffer, &start);
	gtk_text_buffer_get_end_iter (buffer, &end);
	text = gtk_text_buffer_get_text (buffer, &start, &end, FALSE);       
	gtk_text_buffer_set_modified (buffer, FALSE);
	gtk_widget_set_sensitive (lookup_widget(window,"text_view"), TRUE);
        
	/* set the contents of the file to the text from the buffer */
	if (filename_A != NULL)        
		result = g_file_set_contents (filename_A, text, -1, &err);
	else
		result = g_file_set_contents (filename, text, -1, &err);
                
	if (result == FALSE)
	{
		/* error saving file, show message to user */
		error_message (err->message);
		g_error_free (err);
	}        
        
	/* don't forget to free that memory! */ 
	g_free (text); 
        
	if (filename_A != NULL) 
	{
        /* we need to free the memory used by editor->filename and set 
		it to the new filename instead */
		if (filename != NULL) g_free (filename);
		filename = filename_A;
	}
        
	/* clear saving status and restore default */
        gtk_statusbar_pop (GTK_STATUSBAR (lookup_widget(window,"statusbar")),
                           statusbar_context_id);
	reset_default_status (window);   
}

gchar *
get_save_filename (GtkWidget     *window)
{
	GtkWidget               *chooser;

	gchar *filename_A = NULL;
	
	chooser = gtk_file_chooser_dialog_new ("Guardar Archivo...",
					      				GTK_WINDOW (window),
							       		GTK_FILE_CHOOSER_ACTION_SAVE,
	      								GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
       									GTK_STOCK_SAVE, GTK_RESPONSE_OK,
       									NULL);
                                               
	if (gtk_dialog_run (GTK_DIALOG (chooser)) == GTK_RESPONSE_OK)
	{
		filename_A = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (chooser));
	}
        
	gtk_widget_destroy (chooser);
	return filename_A;
}

void
on_new_menu_item_activate              (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        GtkTextBuffer           *buffer;
        
        if (check_for_save (window) == TRUE)
        {
              on_save_menu_item_activate (NULL, window);  
        }
        
        /* clear editor for a new file */
        filename = NULL;
	    buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW(lookup_widget(window,"text_view")));
        gtk_text_buffer_set_text (buffer, "", -1);
        gtk_text_buffer_set_modified (buffer, FALSE);
        
        reset_default_status (window);
}


void
on_open_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        gchar                   *filename_A;
        
        if (check_for_save (window) == TRUE)
        {
              on_save_menu_item_activate (NULL, window);  
        }
        
        filename_A = get_open_filename (window);
        if (filename_A != NULL) load_file (window, filename_A); 
}


void
on_save_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        gchar                   *filename_A = NULL;
       
	if (filename_A == NULL) 
	{
		filename_A = get_save_filename (window);
		if (filename_A != NULL) write_file (window, filename_A); 
	}
	else write_file (window, NULL);
}


void
on_save_as_menu_item_activate          (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        gchar                   *filename_A;
        
        filename_A = get_save_filename (window);
        if (filename_A != NULL) write_file (window, filename_A); 
}


void
on_quit_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
	if (check_for_save (window) == TRUE)
	{
		on_save_menu_item_activate (NULL, window);  
	}
	gtk_main_quit();
}


void
on_cut_menu_item_activate              (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        GtkTextBuffer           *buffer;
        GtkClipboard            *clipboard;
        
        clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (lookup_widget(window,"text_view")));
        gtk_text_buffer_cut_clipboard (buffer, clipboard, TRUE);
}


void
on_copy_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        GtkTextBuffer           *buffer;
        GtkClipboard            *clipboard;
        
        clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (lookup_widget(window,"text_view")));
        gtk_text_buffer_copy_clipboard (buffer, clipboard);
}


void
on_paste_menu_item_activate            (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        GtkTextBuffer           *buffer;
        GtkClipboard            *clipboard;
        
        clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (lookup_widget(window,"text_view")));
        gtk_text_buffer_paste_clipboard (buffer, clipboard, NULL, TRUE);
}


void
on_delete_menu_item_activate           (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
        GtkTextBuffer           *buffer;

        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (lookup_widget(window,"text_view")));
        gtk_text_buffer_delete_selection (buffer, FALSE, TRUE);
}


void
on_boton_imprimir_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window)
{

}


void
on_about_menu_item_activate            (GtkMenuItem     *menuitem,
                                        gpointer         window)
{
	static const gchar * const authors[] = {
		"Rosales Victor y German Sanguinetti",
  NULL
	};

	static const gchar copyright[] = \
			"CopyLeft";

	static const gchar comments[] = "Editor de texto braille";

	gtk_show_about_dialog (GTK_WINDOW (window),
			       "authors", authors,
	  "comments", comments,
   "copyright", copyright,
   "version", "0.1",
   "website", "http://",
   "program-name", "Braille Text Editor",
   "logo-icon-name", GTK_STOCK_EDIT,
   NULL); 
}

