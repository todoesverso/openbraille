#include <gtk/gtk.h>


void on_window_destroy (GtkWindow *window);   //Esta funcion  esta demas ya se conecto la señal destroy en interface.c

void
error_message 						   (const gchar *message);

void 
reset_default_status 				   (GtkWidget *window);

gboolean 
check_for_save 						   (GtkWidget *window);

gchar *
get_open_filename 					   (GtkWidget *window);

void 
load_file 							   (GtkWidget *window, gchar *filename_A);

void 
write_file 							   (GtkWidget	*window, gchar *filename);

gchar *
get_save_filename 					   (GtkWidget     *window);

void
on_save_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_new_menu_item_activate              (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_open_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);



void
on_save_as_menu_item_activate          (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_quit_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_cut_menu_item_activate              (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_copy_menu_item_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_paste_menu_item_activate            (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_delete_menu_item_activate           (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_boton_imprimir_activate             (GtkMenuItem     *menuitem,
                                        gpointer         window);

void
on_about_menu_item_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data);
